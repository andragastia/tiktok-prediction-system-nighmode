"""
Utility modules for TikTok Prediction System
"""
