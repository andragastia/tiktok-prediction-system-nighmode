"""
Temporary script to inspect the model and dataset
This will help us understand the model structure and features
"""
import joblib
import pandas as pd
import numpy as np
import sys
import io

# Fix encoding for Windows console
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

print("=" * 60)
print("MODEL INSPECTION")
print("=" * 60)

# Load model
model_path = "models/tiktok_model_final_CLASSIFIER.pkl"
model = joblib.load(model_path)

print(f"\n✅ Model loaded successfully!")
print(f"Model type: {type(model).__name__}")
print(f"Model class: {model.__class__}")

# Check if it's a pipeline or direct model
if hasattr(model, 'named_steps'):
    print("\n📦 Model is a Pipeline with steps:")
    for step_name, step in model.named_steps.items():
        print(f"  - {step_name}: {type(step).__name__}")

    # Get the classifier
    if 'classifier' in model.named_steps:
        classifier = model.named_steps['classifier']
    else:
        # Try to get the last step
        classifier = list(model.named_steps.values())[-1]
else:
    classifier = model

print(f"\n🎯 Classifier type: {type(classifier).__name__}")

# Try to get feature information
if hasattr(model, 'feature_names_in_'):
    print(f"\n📊 Number of features: {len(model.feature_names_in_)}")
    print(f"Features: {list(model.feature_names_in_)}")
elif hasattr(classifier, 'feature_names_in_'):
    print(f"\n📊 Number of features: {len(classifier.feature_names_in_)}")
    print(f"Features: {list(classifier.feature_names_in_)}")
elif hasattr(classifier, 'n_features_in_'):
    print(f"\n📊 Number of features: {classifier.n_features_in_}")
    print("⚠️ Feature names not available in model")
else:
    print("\n⚠️ Cannot determine number of features")

# Check classes
if hasattr(classifier, 'classes_'):
    print(f"\n🏷️ Classes: {classifier.classes_}")
    print(f"Class mapping: 0 = Tidak Trending, 1 = Trending")

# Check if Random Forest
if hasattr(classifier, 'n_estimators'):
    print(f"\n🌲 Random Forest configuration:")
    print(f"  - Number of trees: {classifier.n_estimators}")
    if hasattr(classifier, 'max_depth'):
        print(f"  - Max depth: {classifier.max_depth}")
    if hasattr(classifier, 'min_samples_split'):
        print(f"  - Min samples split: {classifier.min_samples_split}")

print("\n" + "=" * 60)
print("DATASET INSPECTION")
print("=" * 60)

# Load dataset
data_path = "data/dataset_tiktok.csv"
df = pd.read_csv(data_path)

print(f"\n✅ Dataset loaded successfully!")
print(f"Dataset shape: {df.shape}")
print(f"Total records: {len(df)}")
print(f"Total columns: {len(df.columns)}")

print(f"\n📋 Column names:")
for i, col in enumerate(df.columns, 1):
    print(f"  {i}. {col}")

print(f"\n📊 Data types:")
print(df.dtypes)

print(f"\n📈 Basic statistics:")
print(df.describe())

print(f"\n❓ Missing values:")
print(df.isnull().sum())

print(f"\n📌 First 3 rows:")
print(df.head(3))

print("\n" + "=" * 60)
print("ANALYSIS COMPLETE")
print("=" * 60)
