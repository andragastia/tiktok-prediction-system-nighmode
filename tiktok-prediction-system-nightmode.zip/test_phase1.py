"""
Test Phase 1 utilities
"""
import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

from utils.model_handler import get_model_handler
from utils.data_processor import get_data_processor

print("="*60)
print("TESTING PHASE 1 UTILITIES")
print("="*60)

# Test Model Handler
print("\n1. Testing Model Handler...")
model_handler = get_model_handler()
print("   ✅ Model loaded successfully")

model_info = model_handler.get_model_info()
print(f"   - Model type: {model_info['model_type']}")
print(f"   - Number of features: {model_info['n_features']}")
print(f"   - Number of trees: {model_info.get('n_estimators', 'N/A')}")

# Test Data Processor
print("\n2. Testing Data Processor...")
data_processor = get_data_processor()
print("   ✅ Data loaded successfully")

stats = data_processor.get_summary_stats()
print(f"   - Total videos: {stats['total_videos']}")
print(f"   - Total views: {stats['total_views']:,}")
print(f"   - Avg engagement rate: {stats['avg_engagement_rate']:.2f}%")

# Test getting top videos
print("\n3. Testing Top Videos Function...")
top_videos = data_processor.get_top_videos(n=5)
print(f"   ✅ Retrieved top {len(top_videos)} videos")
print(f"   - Best video views: {top_videos.iloc[0]['playCount']:,}")

# Test performance by day
print("\n4. Testing Performance by Day...")
perf_by_day = data_processor.get_performance_by_day()
print(f"   ✅ Retrieved performance for {len(perf_by_day)} days")
print(f"   - Best day: {perf_by_day['playCount'].idxmax()}")

# Test feature importance
print("\n5. Testing Feature Importance...")
feature_imp = model_handler.get_feature_importance()
if feature_imp is not None:
    print("   ✅ Feature importance retrieved")
    print("   - Top 5 features:")
    for idx, row in feature_imp.head(5).iterrows():
        print(f"     {row['feature']}: {row['importance']:.4f}")

print("\n" + "="*60)
print("PHASE 1 TESTING COMPLETE ✅")
print("="*60)
