# TikTok Content Performance Prediction System

## Project Overview
Sistem prediksi performa konten TikTok untuk creator @septianndt menggunakan Random Forest Classifier. 
Target: Prediksi kategori "Trending" atau "Tidak Trending" untuk membantu strategi konten.

**Academic Context**: Tugas Akhir Skripsi - Implementasi Data Mining
**Institution**: UPN Veteran Jakarta - Fakultas Ilmu Komputer, S1 Sistem Informasi
**Timeline**: 2 Hari
**Development Tool**: Claude Code in VSCode

---

## Tech Stack
- **Framework**: Streamlit (web-based UI)
- **ML Model**: Random Forest Classifier (pre-trained)
- **Data Processing**: Pandas, NumPy
- **Visualization**: Plotly
- **Language**: Python 3.8+
- **UI Language**: Bahasa Indonesia (all user-facing text)

---

## Project Structure
```
tiktok-prediction-system/
├── app.py                          # Main Streamlit app (entry point)
├── pages/
│   ├── 1_📊_Analytics_Dashboard.py # Analytics & insights
│   ├── 2_🔮_Prediction.py          # Single prediction form
│   └── 3_📤_Batch_Prediction.py    # Batch CSV prediction
├── models/
│   └── tiktok_model_final_CLASSIFIER.pkl  # Pre-trained model
├── data/
│   └── dataset_freetiktokscraper_20251111_031559826.csv  # Training data
├── utils/
│   ├── data_processor.py           # Data loading & preprocessing
│   ├── model_handler.py            # Model operations
│   └── visualizations.py           # Chart helpers
├── requirements.txt                # Dependencies
├── CLAUDE.md                       # This file
├── SKILL_INDONESIAN_UI.md          # UI language guide
├── .gitignore
└── README.md
```

---

## Model Information

### Model Details
- **File**: `tiktok_model_final_CLASSIFIER.pkl`
- **Algorithm**: Random Forest Classifier
- **Status**: Pre-trained and finalized (DO NOT retrain)
- **Target Variable**: Binary Classification
  - Class 0: "Tidak Trending"
  - Class 1: "Trending"

### Model Features
Extract features from the .pkl file in Phase 1. Expected features based on reference:
- Engagement metrics: likes, comments, shares
- Video properties: duration, content type, audio type
- Temporal: upload day, upload hour
- Derived features: engagement rate, etc.

**Action**: Inspect model using joblib in Phase 1 to get exact feature list and preprocessing requirements.

---

## Dataset Information

### Source
- **Origin**: TikTok Analytics - @septianndt account
- **Collection Method**: FreeTikTokScraper
- **File**: `dataset_freetiktokscraper_20251111_031559826.csv`

### Dataset Stats
- **Total Records**: 159 videos
- **Columns**: 13 columns

### Column Descriptions
| Column | Type | Description |
|--------|------|-------------|
| authorMeta.avatar | String | Creator avatar URL |
| authorMeta.name | String | Creator name |
| text | String | Video caption/description |
| diggCount | Integer | Number of likes |
| shareCount | Integer | Number of shares |
| playCount | Integer | Number of views (plays) |
| commentCount | Integer | Number of comments |
| videoMeta.duration | Integer | Video duration in seconds |
| musicMeta.musicName | String | Music track name |
| musicMeta.musicAuthor | String | Music artist |
| musicMeta.musicOriginal | Boolean | Is original audio |
| createTimeISO | Date | Upload timestamp (ISO format) |
| webVideoUrl | String | TikTok video URL |

### Usage
- **Analytics Dashboard**: Full dataset for insights
- **Batch Prediction**: Validation & comparison
- **Model Testing**: Verify predictions accuracy

---

## Project Objectives

### 1. Model Implementation (Priority: HIGH)
- Load pre-trained Random Forest model
- Implement prediction pipeline
- Ensure model accuracy & reliability

### 2. Analytics Dashboard (Priority: HIGH)
**Goal**: Comprehensive content performance analysis

**Components**:
- **Overview Metrics**: KPI cards with summary stats
- **Temporal Analysis**: 
  - Best day to post (heatmap/bar chart)
  - Best time to post (hourly analysis)
  - Posting patterns over time
- **Content Type Analysis**:
  - Performance by content type (OOTD, Tutorial, Vlog, etc.)
  - Distribution of content types
- **Audio Analysis**:
  - Original vs Trending audio performance
  - Top performing music tracks
- **Top Performers**:
  - Top 10 videos by views
  - Top 10 by engagement rate
  - Recent trending content
- **Engagement Patterns**:
  - Correlation between metrics
  - Engagement rate trends

### 3. Single Prediction (Priority: MEDIUM)
**Goal**: Interactive form for individual prediction

**Features**:
- User-friendly input form for all required features
- Real-time prediction on submit
- Confidence score display
- Feature importance for this prediction
- Actionable recommendations

### 4. Batch Prediction (Priority: MEDIUM)
**Goal**: Mass prediction via CSV upload

**Features**:
- CSV file upload interface
- Format validation
- Bulk prediction processing
- Predicted vs Actual comparison (if labels available)
- Confusion matrix & accuracy metrics
- Download results as CSV/Excel

---

## Development Phases

### 🔵 PHASE 1: Foundation & Setup
**Duration**: 30-45 minutes
**Dependencies**: None
**Priority**: CRITICAL

#### Objectives
- Setup complete project structure
- Analyze model & dataset thoroughly
- Create core utility functions

#### Deliverables
```
✅ Folder structure created
✅ utils/model_handler.py (load model, predict, get features)
✅ utils/data_processor.py (load data, preprocess)
✅ Model features documented
✅ Dataset loaded & analyzed
```

#### Tasks
1. Create all directories and base files
2. Load `tiktok_model_final_CLASSIFIER.pkl` using joblib
3. Inspect model to extract:
   - Required features (names & order)
   - Feature types (numeric/categorical)
   - Expected input format
   - Preprocessing requirements (scaling, encoding, etc.)
4. Load and analyze dataset CSV:
   - Check data types
   - Identify missing values
   - Calculate basic statistics
   - Understand data distribution
5. Create helper functions:
   - `load_model()`: Load .pkl file safely
   - `load_data()`: Load CSV with error handling
   - `preprocess_input()`: Prepare data for model
   - `predict()`: Run prediction with model

#### Validation Criteria
- [ ] Model loads without errors
- [ ] All features documented with types
- [ ] Dataset loads and displays correctly
- [ ] Helper functions tested manually
- [ ] No hardcoded paths (use relative paths)

#### Output Example
```python
# Expected output in terminal/notebook
Model loaded successfully!
Model type: RandomForestClassifier
Number of features: 15
Features: ['likes', 'comments', 'shares', ...]
Classes: [0, 1] (Tidak Trending, Trending)
Dataset shape: (159, 13)
Missing values: 0
```

---

### 🟢 PHASE 2: Analytics Dashboard - Part 1 (Overview)
**Duration**: 45-60 minutes
**Dependencies**: Phase 1
**Priority**: HIGH

#### Objectives
- Setup Streamlit multi-page architecture
- Create main navigation
- Build overview metrics section
- Implement basic visualizations

#### Deliverables
```
✅ app.py (main entry with sidebar navigation)
✅ pages/1_📊_Analytics_Dashboard.py (50% complete)
✅ utils/visualizations.py (chart helper functions)
✅ Overview KPI cards working
✅ 2-3 basic charts rendered
```

#### Tasks

**1. Setup Main App (app.py)**
```python
# Structure:
- Page config (title, icon, layout)
- Sidebar with navigation info
- Welcome message
- Quick stats summary
- Link to dashboard pages
```

**2. Create KPI Cards**
Display these metrics prominently:
- Total Videos Published
- Total Views (sum of playCount)
- Total Likes (sum of diggCount)
- Total Comments (sum of commentCount)
- Total Shares (sum of shareCount)
- Average Engagement Rate = (likes + comments + shares) / views
- Best Performing Video (by views)

**3. Basic Visualizations**
- **Line Chart**: Views over time (by upload date)
- **Bar Chart**: Total engagement by month
- **Distribution**: Views distribution (histogram)

**4. Layout Design**
- Use `st.columns()` for KPI cards (3-4 per row)
- Use `st.container()` for chart sections
- Add section headers with icons
- Apply TikTok color theme

#### Validation Criteria
- [ ] App runs without errors (`streamlit run app.py`)
- [ ] Navigation sidebar visible and functional
- [ ] KPI cards display correct calculations
- [ ] Charts render with proper labels
- [ ] All text in Bahasa Indonesia
- [ ] Mobile-responsive layout

#### UI Elements (Indonesian)
```python
st.title("🎯 Sistem Prediksi Performa Konten TikTok")
st.header("📊 Ringkasan Performa")
col1.metric("Total Video", total_videos)
col2.metric("Total Tayangan", f"{total_views:,}")
st.plotly_chart(fig, use_container_width=True)
```

---

### 🟡 PHASE 3: Analytics Dashboard - Part 2 (Deep Analysis)
**Duration**: 45-60 minutes
**Dependencies**: Phase 2
**Priority**: HIGH

#### Objectives
- Complete analytics dashboard with advanced insights
- Add interactive filters and drill-downs
- Create comprehensive visualizations

#### Deliverables
```
✅ pages/1_📊_Analytics_Dashboard.py (100% complete)
✅ Advanced visualizations (heatmap, grouped charts)
✅ Interactive filters working
✅ All analysis sections implemented
```

#### Tasks

**1. Temporal Analysis Section**

A. **Best Day to Post**
- Extract day of week from createTimeISO
- Calculate average views per day
- Create bar chart or heatmap
- Show best performing day

B. **Best Time to Post**
- Extract hour from createTimeISO
- Calculate average views per hour
- Create line chart
- Highlight peak hours

C. **Posting Heatmap** (Optional but recommended)
- Day (rows) vs Hour (columns)
- Cell color = average views
- Use Plotly heatmap

**2. Content Type Analysis**

A. **Content Type Distribution**
- Pie chart or donut chart
- Show percentage of each type
- Count of videos per type

B. **Performance by Content Type**
- Grouped bar chart:
  - X-axis: Content type
  - Y-axis: Average views/likes/comments
- Box plot: Views distribution per type
- Table: Stats summary per type

C. **Best Content Type**
- Identify highest performing type
- Show comparative metrics
- Recommendation text

**3. Audio Analysis**

A. **Original vs Trending Audio**
- Compare performance metrics
- Bar chart: Original vs Trending (avg views)
- Show preference insights

B. **Top Music Tracks** (if data available)
- Top 10 music tracks by views
- Bar chart: Music name vs Total views
- Identify viral audio

**4. Top Performers Section**

A. **Top 10 Videos by Views**
- Table with: Video text, Views, Likes, Comments, Shares
- Clickable video URLs
- Thumbnail images (if possible)

B. **Top 10 by Engagement Rate**
- Calculate engagement rate per video
- Highlight overperformers
- Show what makes them successful

C. **Recent Trending**
- Last 30 days top content
- Trend indicators (↑↓)

**5. Engagement Patterns**

A. **Correlation Matrix**
- Heatmap showing correlation between:
  - Views, Likes, Comments, Shares, Duration
- Identify strong relationships

B. **Engagement Rate Trends**
- Line chart: Engagement rate over time
- Moving average overlay
- Trend direction

**6. Interactive Filters** (Sidebar)
- Date range selector
- Content type multiselect
- Audio type filter
- Minimum views threshold

#### Validation Criteria
- [ ] All sections render without errors
- [ ] Charts are interactive (hover, zoom)
- [ ] Filters update visualizations dynamically
- [ ] Insights are clear and actionable
- [ ] Layout is clean and organized
- [ ] Loading times are acceptable (<3 seconds)
- [ ] All text follows SKILL_INDONESIAN_UI.md

#### Expected Output
- Comprehensive dashboard with 8-10 visualizations
- Clear insights for content strategy
- User-friendly navigation
- Professional appearance

---

### 🔵 PHASE 4: Single Prediction Page
**Duration**: 45-60 minutes
**Dependencies**: Phase 1
**Priority**: MEDIUM-HIGH

#### Objectives
- Create interactive prediction form
- Implement real-time prediction
- Display results with explanations

#### Deliverables
```
✅ pages/2_🔮_Prediction.py (complete)
✅ Input form with all required features
✅ Prediction logic working
✅ Results display with confidence
✅ Feature importance visualization
✅ Recommendations engine
```

#### Tasks

**1. Build Input Form**

Create form with these input fields (adjust based on Phase 1 model analysis):
```python
# Example structure (adjust to actual model features)
with st.form("prediction_form"):
    col1, col2 = st.columns(2)
    
    with col1:
        likes = st.number_input("Jumlah Suka", min_value=0, value=100)
        comments = st.number_input("Jumlah Komentar", min_value=0, value=10)
        shares = st.number_input("Jumlah Dibagikan", min_value=0, value=5)
    
    with col2:
        duration = st.number_input("Durasi Video (detik)", min_value=1, value=30)
        content_type = st.selectbox("Tipe Konten", 
            ["OOTD", "Tutorial", "Vlog", "Lainnya"])
        audio_type = st.selectbox("Tipe Audio", 
            ["Audio Original", "Audio Trending", "Audio Lainnya"])
    
    upload_day = st.selectbox("Hari Upload", 
        ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"])
    upload_hour = st.slider("Jam Upload", 0, 23, 12)
    
    submit = st.form_submit_button("🔮 Prediksi Sekarang")
```

**2. Input Validation**
- Check all required fields filled
- Validate numeric ranges
- Ensure logical consistency
- Show error messages if invalid

**3. Prediction Pipeline**
```python
if submit:
    # 1. Validate inputs
    if not validate_inputs(inputs):
        st.error("Mohon lengkapi semua field")
        return
    
    # 2. Preprocess inputs to match model format
    processed_data = preprocess_input(inputs)
    
    # 3. Run prediction
    prediction = model.predict(processed_data)
    prediction_proba = model.predict_proba(processed_data)
    
    # 4. Display results
    show_prediction_results(prediction, prediction_proba)
```

**4. Results Display**

**A. Prediction Result**
- Large, prominent display
- Use colors: Green (Trending) / Red (Tidak Trending)
- Animation or icon

**B. Confidence Score**
- Progress bar showing probability
- Percentage display
- Confidence level interpretation

**C. Feature Importance**
- Show which features most influenced this prediction
- Bar chart: Top 5 features
- Explanation text

**D. Recommendations**
Based on prediction and inputs:
- If "Trending" predicted:
  - "Konten Anda berpotensi trending! Pastikan..."
  - Tips to maximize reach
- If "Tidak Trending" predicted:
  - "Konten ini mungkin perlu optimasi..."
  - Suggestions to improve (e.g., better timing, different content type)

**5. Additional Features**

A. **Compare with Average**
- Show how inputs compare to average trending content
- Visual indicators (above/below average)

B. **Similar Videos**
- Find 3-5 similar videos from dataset
- Show their performance
- Learn from successful examples

C. **Export Prediction**
- Download prediction result as PDF/CSV
- Include timestamp and input values

#### Validation Criteria
- [ ] All input fields working correctly
- [ ] Form validation prevents invalid submissions
- [ ] Prediction completes in <2 seconds
- [ ] Results display is clear and attractive
- [ ] Confidence score matches prediction
- [ ] Recommendations are relevant
- [ ] Error handling for edge cases
- [ ] All text in Indonesian

#### UI Example
```python
st.title("🔮 Prediksi Performa Video")
st.write("Masukkan informasi video untuk memprediksi potensi trending")

# After prediction
if prediction == 1:
    st.success("🎉 Prediksi: TRENDING!")
    st.metric("Tingkat Keyakinan", f"{confidence}%", 
              delta="Potensi Tinggi")
else:
    st.warning("⚠️ Prediksi: Tidak Trending")
    st.metric("Tingkat Keyakinan", f"{confidence}%")

# Feature importance chart
st.subheader("Faktor Paling Berpengaruh")
st.plotly_chart(feature_importance_chart)

# Recommendations
st.subheader("💡 Rekomendasi")
st.info(recommendations_text)
```

---

### 🟢 PHASE 5: Batch Prediction Page
**Duration**: 45-60 minutes
**Dependencies**: Phase 1, Phase 4
**Priority**: MEDIUM

#### Objectives
- Create CSV upload interface
- Implement batch prediction
- Create comparison analysis
- Enable results export

#### Deliverables
```
✅ pages/3_📤_Batch_Prediction.py (complete)
✅ CSV upload with validation
✅ Batch prediction working
✅ Predicted vs Actual comparison
✅ Download functionality
✅ Performance metrics visualization
```

#### Tasks

**1. CSV Upload Interface**
```python
st.title("📤 Prediksi Massal (Batch)")
st.write("Unggah file CSV untuk memprediksi banyak video sekaligus")

# File uploader
uploaded_file = st.file_uploader(
    "Pilih file CSV",
    type=['csv'],
    help="Format: harus memiliki kolom yang sesuai dengan model"
)

# Sample CSV download
st.download_button(
    "📥 Unduh Template CSV",
    data=sample_csv_data,
    file_name="template_prediksi.csv",
    mime="text/csv"
)
```

**2. File Validation**
```python
if uploaded_file:
    # Load CSV
    df = pd.read_csv(uploaded_file)
    
    # Validate columns
    required_columns = get_required_columns()
    missing_columns = set(required_columns) - set(df.columns)
    
    if missing_columns:
        st.error(f"Kolom yang hilang: {missing_columns}")
        st.stop()
    
    # Validate data types
    if not validate_data_types(df):
        st.error("Tipe data tidak sesuai")
        st.stop()
    
    # Show preview
    st.success("✅ File berhasil diunggah!")
    st.dataframe(df.head())
    st.write(f"Total baris: {len(df)}")
```

**3. Batch Prediction Processing**
```python
if st.button("🚀 Jalankan Prediksi"):
    with st.spinner("Sedang memproses prediksi..."):
        # Preprocess all rows
        processed_data = preprocess_batch(df)
        
        # Run predictions
        predictions = model.predict(processed_data)
        prediction_probas = model.predict_proba(processed_data)
        
        # Add results to dataframe
        df['Prediksi'] = predictions
        df['Prediksi_Label'] = df['Prediksi'].map({
            0: 'Tidak Trending',
            1: 'Trending'
        })
        df['Confidence'] = prediction_probas.max(axis=1)
        
        # Display results
        st.success("✅ Prediksi selesai!")
        st.dataframe(df)
```

**4. Comparison Analysis (if actual labels exist)**

Check if CSV has actual labels column (e.g., 'Actual', 'Label', or similar):
```python
if 'Actual' in df.columns:
    st.subheader("📊 Analisis Perbandingan")
    
    # Calculate metrics
    from sklearn.metrics import (
        confusion_matrix, 
        accuracy_score, 
        precision_score, 
        recall_score, 
        f1_score,
        classification_report
    )
    
    y_true = df['Actual']
    y_pred = df['Prediksi']
    
    # Metrics
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Akurasi", f"{accuracy_score(y_true, y_pred):.2%}")
    col2.metric("Presisi", f"{precision_score(y_true, y_pred):.2%}")
    col3.metric("Recall", f"{recall_score(y_true, y_pred):.2%}")
    col4.metric("F1-Score", f"{f1_score(y_true, y_pred):.2%}")
    
    # Confusion Matrix
    cm = confusion_matrix(y_true, y_pred)
    fig = create_confusion_matrix_plot(cm)
    st.plotly_chart(fig)
    
    # Classification Report
    st.text("Laporan Klasifikasi:")
    st.text(classification_report(y_true, y_pred, 
        target_names=['Tidak Trending', 'Trending']))
    
    # Misclassification Analysis
    misclassified = df[df['Actual'] != df['Prediksi']]
    if len(misclassified) > 0:
        st.subheader("❌ Video yang Salah Diprediksi")
        st.dataframe(misclassified)
        st.write(f"Total: {len(misclassified)} dari {len(df)} video")
```

**5. Visualizations**

A. **Prediction Distribution**
- Pie chart: Trending vs Tidak Trending
- Bar chart: Count by prediction

B. **Confidence Distribution**
- Histogram: Confidence scores
- Identify low-confidence predictions

C. **Comparison Charts** (if actuals available)
- Confusion matrix heatmap
- Precision-Recall curve
- ROC curve (optional)

**6. Export Results**
```python
# CSV Export
csv_data = df.to_csv(index=False)
st.download_button(
    "📥 Unduh Hasil Prediksi (CSV)",
    data=csv_data,
    file_name=f"hasil_prediksi_{timestamp}.csv",
    mime="text/csv"
)

# Excel Export (optional)
excel_data = to_excel(df)
st.download_button(
    "📥 Unduh Hasil Prediksi (Excel)",
    data=excel_data,
    file_name=f"hasil_prediksi_{timestamp}.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
)

# Summary Report (optional)
if st.button("📄 Generate Summary Report"):
    report_pdf = create_summary_report(df, metrics)
    st.download_button(
        "📥 Unduh Laporan PDF",
        data=report_pdf,
        file_name=f"laporan_prediksi_{timestamp}.pdf",
        mime="application/pdf"
    )
```

#### Validation Criteria
- [ ] CSV upload works for various file sizes
- [ ] File validation prevents bad data
- [ ] Batch prediction handles 100+ rows efficiently
- [ ] Comparison metrics calculated correctly
- [ ] Visualizations render properly
- [ ] Export functions work for all formats
- [ ] Error handling for edge cases
- [ ] Progress indicators for long operations
- [ ] All text in Indonesian

#### Performance Considerations
- Use `st.cache_data` for preprocessing
- Show progress bar for large batches
- Limit preview to first 100 rows if dataset is huge
- Implement pagination for large results

---

### 🟡 PHASE 6: Polish, Testing & Deployment Prep
**Duration**: 45-60 minutes
**Dependencies**: All previous phases
**Priority**: MEDIUM-HIGH

#### Objectives
- Polish UI/UX across all pages
- Comprehensive testing
- Bug fixes and optimizations
- Finalize documentation
- Prepare for deployment

#### Deliverables
```
✅ Consistent UI theme applied
✅ All features tested and working
✅ Critical bugs fixed
✅ Performance optimized
✅ Documentation complete
✅ Deployment-ready application
```

#### Tasks

**1. UI/UX Polish**

A. **Consistent Styling**
- Apply TikTok color scheme:
```python
  # .streamlit/config.toml
  [theme]
  primaryColor = "#00f2ea"
  backgroundColor = "#ffffff"
  secondaryBackgroundColor = "#f0f2f6"
  textColor = "#262730"
  font = "sans serif"
```

- Consistent header hierarchy
- Uniform spacing and padding
- Icon usage for visual appeal
- Color-coded success/warning/error messages

B. **Loading States**
- Add spinners for long operations
- Progress bars for batch processing
- Skeleton loaders for data fetching
- "Processing..." messages

C. **Responsive Design**
- Test on different screen sizes
- Adjust column layouts for mobile
- Ensure charts scale properly
- Fix any overflow issues

D. **Tooltips & Help Text**
- Add `help` parameter to inputs
- Create expandable help sections
- Add "❓" info icons with explanations
- Provide examples for unclear inputs

E. **Error Handling Improvements**
- Friendly error messages
- Clear instructions on how to fix
- Fallback UI for errors
- Log errors for debugging

**2. Comprehensive Testing**

A. **Functional Testing**

Test each page:
- [ ] **Home/Main Page**
  - Navigation works
  - Links functional
  - Information accurate

- [ ] **Analytics Dashboard**
  - All charts render
  - Filters work correctly
  - Data calculations accurate
  - No console errors
  - Interactive elements responsive

- [ ] **Single Prediction**
  - Form accepts valid inputs
  - Form rejects invalid inputs
  - Prediction returns correct results
  - Confidence scores make sense
  - Recommendations relevant
  - Edge cases handled

- [ ] **Batch Prediction**
  - CSV upload works
  - Template download works
  - Validation catches errors
  - Predictions run successfully
  - Comparison metrics accurate
  - Export functions work

B. **Edge Case Testing**
- Empty inputs
- Extreme values (very high/low)
- Missing data
- Invalid file formats
- Large file uploads (>1000 rows)
- Special characters in text
- Different date formats

C. **Cross-Page Testing**
- Navigation between pages smooth
- Session state persists if needed
- No data leakage between pages
- Back button behavior

D. **Performance Testing**
- Page load times (<3 seconds)
- Prediction speed (<2 seconds for single)
- Batch processing reasonable (<1 minute for 100 rows)
- Memory usage acceptable
- No memory leaks

**3. Code Quality**

A. **Code Cleanup**
- Remove unused imports
- Delete commented-out code
- Remove debug print statements
- Consolidate duplicate code
- Organize imports (standard, third-party, local)

B. **Refactoring**
- Extract repeated code into functions
- Move complex logic to utils
- Simplify nested conditionals
- Improve variable naming
- Add type hints (optional but recommended)

C. **Documentation**
- Add docstrings to functions:
```python
  def predict_trending(features):
      """
      Prediksi kategori trending untuk video TikTok.
      
      Args:
          features (dict): Dictionary berisi fitur video
          
      Returns:
          tuple: (prediction, confidence_score)
      """
      ...
```
- Add inline comments for complex logic
- Update function descriptions

D. **Code Standards**
- Consistent indentation (4 spaces)
- Max line length (79-100 characters)
- Consistent naming conventions
- Follow PEP 8 guidelines (for Python)

**4. Bug Fixes**

Priority bug fixes:
- [ ] Any crashes or exceptions
- [ ] Incorrect calculations
- [ ] Broken links or navigation
- [ ] Non-responsive UI elements
- [ ] Data not displaying
- [ ] Export functions failing

Create a bug list and address systematically.

**5. Performance Optimization**

A. **Caching**
```python
@st.cache_data
def load_data():
    """Cache dataset loading"""
    return pd.read_csv('data/dataset.csv')

@st.cache_resource
def load_model():
    """Cache model loading"""
    return joblib.load('models/tiktok_model.pkl')
```

B. **Lazy Loading**
- Load heavy visualizations only when needed
- Defer non-critical computations
- Use `st.empty()` for dynamic updates

C. **Data Optimization**
- Filter data before processing
- Use efficient pandas operations
- Avoid loops where possible
- Downsample large datasets for visualization

**6. Documentation Finalization**

A. **Update README.md**
- Add project description
- Installation instructions
- Usage guide with screenshots
- Feature descriptions
- Known limitations
- Troubleshooting section
- Credits and references

B. **Create User Guide** (Optional)
- Step-by-step usage instructions
- Screenshots of each page
- Example workflows
- FAQs

C. **Technical Documentation**
- Model specifications
- Feature engineering details
- API/function reference (if applicable)
- Architecture diagram

D. **Code Comments**
- Ensure all complex code is commented
- Add file headers with purpose
- Document assumptions

**7. Deployment Preparation**

A. **Environment Check**
- Verify requirements.txt is complete
- Test installation on fresh environment
- Check Python version compatibility
- Document system requirements

B. **Configuration**
- Create `.streamlit/config.toml` for settings
- Add secrets management if needed
- Configure for production (caching, etc.)

C. **Deployment Options**

**Option 1: Streamlit Cloud** (Recommended)
- Push to GitHub
- Connect Streamlit Cloud
- Deploy automatically

**Option 2: Local Deployment**
- Provide run instructions
- Document port and network requirements

**Option 3: Docker** (Advanced)
- Create Dockerfile (optional)
- Document container setup

D. **Pre-deployment Checklist**
- [ ] All features working
- [ ] No hardcoded secrets/passwords
- [ ] Relative paths used (not absolute)
- [ ] .gitignore properly configured
- [ ] README.md complete
- [ ] requirements.txt accurate
- [ ] Test on clean environment
- [ ] Performance acceptable

**8. Final Testing**

A. **User Acceptance Testing**
- Walk through as an end user
- Test all user journeys
- Check for confusion points
- Ensure instructions are clear

B. **Stress Testing**
- Try breaking the app intentionally
- Upload malformed files
- Enter nonsensical inputs
- Test with slow internet (if deployed)

C. **Accessibility Check**
- Text is readable (font size, contrast)
- Color-blind friendly colors
- Keyboard navigation works
- Screen reader compatible (basic)

**9. Known Issues Documentation**

Create a list of known limitations:
- Dataset size limitations
- Supported browsers
- Feature constraints
- Performance considerations

**10. Handoff Preparation**

Prepare for demo/presentation:
- [ ] Clean, sample data ready
- [ ] Demo script prepared
- [ ] Screenshots captured
- [ ] Video recording (optional)
- [ ] Presentation slides (if needed)

#### Validation Criteria
- [ ] UI is consistent across all pages
- [ ] All features tested and working
- [ ] No critical bugs remaining
- [ ] Performance is acceptable
- [ ] Code is clean and documented
- [ ] README is comprehensive
- [ ] App runs on fresh environment
- [ ] Ready for user demo/presentation

#### Final Deliverable
A polished, production-ready TikTok Content Performance Prediction System that is:
- Functional and reliable
- User-friendly and intuitive
- Well-documented
- Ready for deployment or demonstration

---

## Phase Management Guidelines

### Starting Each Phase

**1. Context Loading**
```markdown
Phase X: [Name]
Dependencies: [List phases]
Estimated time: [Duration]
```

**2. Pre-flight Checklist**
- [ ] Previous phase deliverables complete
- [ ] Required files accessible
- [ ] Dependencies installed
- [ ] CLAUDE.md and SKILL_INDONESIAN_UI.md referenced

**3. During Development**
- Focus only on current phase objectives
- Don't add features outside scope
- Test incrementally
- Document any blockers

**4. Phase Completion**
- [ ] All deliverables created
- [ ] Validation criteria met
- [ ] Quick functionality test
- [ ] Code saved/committed

### Between Phases

**Handoff Template**:
```markdown
## Phase X Completed ✅

### Deliverables
- [✅/❌] Item 1
- [✅/❌] Item 2
- ...

### Issues Encountered
- Issue 1: [Description] - [Resolution]
- ...

### Notes for Next Phase
- Important context or dependencies
- Files created/modified
- Any deviations from plan

### Next Phase
Phase Y: [Name]
Ready to proceed: [Yes/No]
```

### Emergency Protocols

**If Auto-Compact Occurs:**
1. **Immediately save** all progress
2. **Document** current state
3. **Note** last successful checkpoint
4. **Resume** with: "Continue Phase X from [checkpoint]"

**If Stuck:**
1. **Assess** the blocker
2. **Simplify** scope if needed
3. **Skip** non-critical parts temporarily
4. **Mark** for Phase 6 revisit

**If Behind Schedule:**
1. **Prioritize** must-have features
2. **Defer** nice-to-have features
3. **Simplify** UI if needed
4. **Focus** on core functionality

---

## Key Success Factors

### Priority Order
1. **Model Accuracy**: Predictions must be reliable
2. **Core Functionality**: All main features working
3. **User Experience**: Easy to use and understand
4. **Visual Appeal**: Professional and attractive
5. **Documentation**: Clear instructions

### Quality Metrics
- **Functionality**: All features work as intended
- **Performance**: Fast response times
- **Usability**: Intuitive for non-technical users
- **Maintainability**: Clean, documented code
- **Scalability**: Can handle reasonable data volumes

### Must-Have Features
- ✅ Model loads and predicts correctly
- ✅ Analytics dashboard with key insights
- ✅ Single prediction form working
- ✅ Batch prediction from CSV
- ✅ Results display and export
- ✅ All text in Indonesian
- ✅ Error handling

### Nice-to-Have Features
- 🌟 Advanced visualizations
- 🌟 Detailed recommendations
- 🌟 Export to multiple formats
- 🌟 Comparison with historical data
- 🌟 Interactive filters
- 🌟 Mobile responsiveness

---

## Technical Guidelines

### Streamlit Best Practices

**1. Page Configuration**
```python
st.set_page_config(
    page_title="Prediksi TikTok",
    page_icon="🎯",
    layout="wide",
    initial_sidebar_state="expanded"
)
```

**2. Caching**
```python
@st.cache_data  # For data
def load_data():
    return pd.read_csv(...)

@st.cache_resource  # For models, connections
def load_model():
    return joblib.load(...)
```

**3. Session State**
```python
if 'key' not in st.session_state:
    st.session_state.key = value
```

**4. Layout**
```python
col1, col2, col3 = st.columns(3)
with col1:
    st.metric(...)

with st.container():
    st.plotly_chart(...)

with st.expander("More Info"):
    st.write(...)
```

**5. User Feedback**
```python
st.success("✅ Berhasil!")
st.error("❌ Gagal!")
st.warning("⚠️ Peringatan")
st.info("ℹ️ Informasi")

with st.spinner("Memproses..."):
    # Long operation
```

### Python Best Practices

**1. Error Handling**
```python
try:
    result = risky_operation()
except SpecificException as e:
    st.error(f"Error: {str(e)}")
    logger.error(f"Error details: {e}")
```

**2. Type Hints**
```python
def predict(features: dict) -> tuple[int, float]:
    """Predict with type hints"""
    ...
```

**3. Constants**
```python
# Define at top of file
TRENDING_THRESHOLD = 10000
MODEL_PATH = "models/tiktok_model.pkl"
DATA_PATH = "data/dataset.csv"
```

**4. Validation**
```python
def validate_input(data: dict) -> bool:
    """Validate input data"""
    required = ['likes', 'comments', 'shares']
    return all(key in data for key in required)
```

### Security Considerations

- Don't hardcode API keys or secrets
- Validate all user inputs
- Sanitize file uploads
- Handle errors gracefully
- Don't expose system paths
- Use relative paths

---

## Commands Reference

### Development Commands
```bash
# Run app
streamlit run app.py

# Run on specific port
streamlit run app.py --server.port 8502

# Run with hot reload (default)
streamlit run app.py

# Install dependencies
pip install -r requirements.txt

# Create virtual environment
python -m venv venv

# Activate venv (Windows)
venv\Scripts\activate

# Activate venv (Mac/Linux)
source venv/bin/activate

# Deactivate venv
deactivate

# Freeze dependencies
pip freeze > requirements.txt

# Check Streamlit version
streamlit --version
```

### Git Commands (if using version control)
```bash
# Initialize git
git init

# Add files
git add .

# Commit
git commit -m "Phase X: [description]"

# Push to remote
git push origin main

# Create branch for phase
git checkout -b phase-1-foundation
```

---

## Troubleshooting

### Common Issues

**1. ModuleNotFoundError**
```bash
# Solution: Install missing package
pip install [package-name]
# Or reinstall all
pip install -r requirements.txt
```

**2. Model Loading Error**
```python
# Check file path
import os
print(os.path.exists('models/tiktok_model.pkl'))

# Check joblib version compatibility
# May need to retrain with same scikit-learn version
```

**3. CSV Encoding Issues**
```python
# Try different encodings
pd.read_csv(file, encoding='utf-8')
pd.read_csv(file, encoding='latin-1')
pd.read_csv(file, encoding='cp1252')
```

**4. Streamlit Port Already in Use**
```bash
# Use different port
streamlit run app.py --server.port 8502
```

**5. Charts Not Displaying**
```python
# Ensure plotly installed
pip install plotly

# Use correct Streamlit method
st.plotly_chart(fig, use_container_width=True)
```

---

## References

### Project Files
- **Model**: `models/tiktok_model_final_CLASSIFIER.pkl`
- **Dataset**: `data/dataset_freetiktokscraper_20251111_031559826.csv`
- **Skripsi BAB I**: `BAB_I-SKRIPSI.docx`
- **Reference**: `Reference.pdf`

### Documentation
- **Main Context**: This file (CLAUDE.md)
- **UI Guide**: SKILL_INDONESIAN_UI.md
- **README**: README.md

### External Resources
- Streamlit Docs: https://docs.streamlit.io
- Plotly Docs: https://plotly.com/python/
- Scikit-learn Docs: https://scikit-learn.org
- Pandas Docs: https://pandas.pydata.org

---

## Project Metadata

- **Project Name**: TikTok Content Performance Prediction System
- **Version**: 1.0
- **Status**: In Development
- **Timeline**: 2 Days
- **Target User**: Content Creator (@septianndt)
- **Primary Language**: Python
- **UI Language**: Bahasa Indonesia
- **Framework**: Streamlit
- **ML Algorithm**: Random Forest Classifier

---

## Notes for Claude Code

### When Starting Each Session:
1. **Read this file** (CLAUDE.md) for context
2. **Read SKILL_INDONESIAN_UI.md** for UI guidelines
3. **Reference the current Phase** objectives
4. **Follow the task list** systematically
5. **Test incrementally** before moving on
6. **Document progress** at phase end

### Communication with Developer:
- **Ask for clarification** if requirements unclear
- **Suggest improvements** if you see opportunities
- **Report blockers** immediately
- **Confirm completion** at phase milestones

### Code Generation Guidelines:
- **Always use Indonesian** for UI text
- **Include error handling** in all functions
- **Add comments** for complex logic
- **Follow PEP 8** style guide
- **Use type hints** where helpful
- **Write testable code**

---

## Success Criteria

### At Project Completion:
- [ ] All 6 phases completed
- [ ] All features functional
- [ ] UI professional and intuitive
- [ ] Code clean and documented
- [ ] Ready for demonstration
- [ ] Deployable to production

### Final Deliverable:
A complete, working TikTok Content Performance Prediction System that:
1. Accurately predicts content performance
2. Provides actionable insights
3. Is easy for content creators to use
4. Looks professional and polished
5. Is well-documented and maintainable

---

*Last Updated: [Date]*
*Project Status: Ready for Development*
*Next Action: Begin Phase 1 - Foundation & Setup*