# 🎯 TikTok Content Performance Prediction System

Sistem prediksi performa konten TikTok untuk membantu content creator @septianndt dalam mengoptimalkan strategi konten menggunakan Random Forest Classifier.

## 🎓 Academic Context
**Tugas Akhir Skripsi** - Implementasi Data Mining untuk Prediksi Trending Video TikTok

## ✨ Features

### 1. 📊 Dashboard Analitik
- Analisis performa konten secara komprehensif
- Visualisasi berdasarkan waktu upload
- Analisis tipe konten dan audio
- Identifikasi pola engagement

### 2. 🔮 Prediksi Tunggal
- Form input interaktif untuk prediksi individual
- Real-time prediction dengan confidence score
- Feature importance analysis
- Rekomendasi strategi konten

### 3. 📤 Prediksi Massal
- Upload CSV untuk batch prediction
- Perbandingan hasil prediksi vs aktual
- Download hasil prediksi
- Visualisasi performa (confusion matrix)

## 🛠️ Tech Stack
- **Framework**: Streamlit
- **ML Model**: Random Forest Classifier
- **Data Processing**: Pandas, NumPy
- **Visualization**: Plotly
- **Language**: Python 3.8+

## 📦 Installation

1. Clone repository
```bash
git clone <repository-url>
cd tiktok-prediction-system
```

2. Create virtual environment
```bash
python -m venv venv
source venv/bin/activate  # Mac/Linux
venv\Scripts\activate     # Windows
```

3. Install dependencies
```bash
pip install -r requirements.txt
```

## 🚀 Usage

Run the Streamlit app:
```bash
streamlit run app.py
```

The app will open in your default browser at `http://localhost:8501`

## 📁 Project Structure
```
tiktok-prediction-system/
├── app.py                          # Main app
├── pages/
│   ├── 1_📊_Analytics_Dashboard.py
│   ├── 2_🔮_Prediction.py
│   └── 3_📤_Batch_Prediction.py
├── utils/
│   ├── data_processor.py
│   ├── model_handler.py
│   └── visualizations.py
├── models/
│   └── tiktok_model_final_CLASSIFIER.pkl
├── data/
│   └── dataset_freetiktokscraper_20251111_031559826.csv
└── requirements.txt
```

## 📊 Dataset Information
- **Source**: TikTok Analytics (@septianndt)
- **Records**: 159 videos
- **Features**: 13 columns including engagement metrics

## 🎯 Model Information
- **Algorithm**: Random Forest Classifier
- **Target**: Binary (Trending / Tidak Trending)
- **Status**: Pre-trained and ready to use

## 👨‍💻 Development

Developed using Claude Code in VSCode with:
- CLAUDE.md for project context
- SKILL_INDONESIAN_UI.md for UI consistency
- Bahasa Indonesia for all user-facing text

## 📝 License
Academic Project - Final Thesis

## 👤 Author
[Your Name]
UPN Veteran Jakarta - Sistem Informasi

## 🙏 Acknowledgments
- Content Creator: @septianndt
- Advisor: [Advisor Name]
- Reference: Meiza Alliansa (2025) - Random Forest Implementation