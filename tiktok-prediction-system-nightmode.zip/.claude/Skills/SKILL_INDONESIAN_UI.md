# Indonesian UI Development Skill

## Purpose
This skill ensures all user-facing text in the Streamlit application uses proper Indonesian language.

## Guidelines

### 1. General Principles
- All UI elements MUST be in Indonesian
- Use formal but friendly tone
- Clear and concise messaging
- Consistent terminology

### 2. Common Translations

#### Navigation & Pages
- Dashboard → Dasbor
- Analytics → Analitik
- Prediction → Prediksi
- Upload → Unggah
- Download → Unduh
- Home → Beranda

#### Actions
- Submit → Kirim
- Reset → Atur Ulang
- Save → Simpan
- Load → Muat
- Process → Proses
- Analyze → Analisis
- Predict → Prediksi

#### Data Elements
- Dataset → Set Data
- Features → Fitur
- Model → Model
- Results → Hasil
- Performance → Performa
- Accuracy → Akurasi
- Metrics → Metrik

#### TikTok Specific
- Views → Jumlah Ditonton / Tayangan
- Likes → Suka / Disukai
- Comments → Komentar
- Shares → Dibagikan
- Trending → Trending / Sedang Tren
- Content → Konten
- Creator → Kreator
- Engagement → Keterlibatan / Engagement

#### Status Messages
- Loading → Memuat...
- Success → Berhasil!
- Error → Terjadi Kesalahan
- Warning → Peringatan
- Please wait → Mohon tunggu...
- Processing → Sedang memproses...

### 3. Example UI Text

#### Headers
```python
st.title("🎯 Sistem Prediksi Performa Konten TikTok")
st.header("📊 Dasbor Analitik")
st.subheader("Ringkasan Performa")
```

#### Descriptions
```python
st.write("Unggah file CSV untuk melakukan prediksi massal")
st.info("Model telah berhasil dimuat dan siap digunakan")
st.success("Prediksi berhasil! Konten Anda diprediksi: Trending")
st.warning("Peringatan: Format file tidak sesuai")
st.error("Gagal memuat model. Silakan hubungi administrator")
```

#### Form Labels
```python
likes = st.number_input("Jumlah Suka", min_value=0)
comments = st.number_input("Jumlah Komentar", min_value=0)
shares = st.number_input("Jumlah Dibagikan", min_value=0)
duration = st.number_input("Durasi Video (detik)", min_value=1)
content_type = st.selectbox("Tipe Konten", ["OOTD", "Tutorial", "Vlog", "Lainnya"])
```

#### Buttons
```python
if st.button("🔮 Prediksi Sekarang"):
    ...
if st.button("📥 Unduh Hasil"):
    ...
if st.button("🔄 Atur Ulang"):
    ...
```

#### Help Text
```python
st.help("Masukkan jumlah suka yang diharapkan untuk video Anda")
with st.expander("ℹ️ Bantuan"):
    st.write("Panduan penggunaan fitur ini...")
```

### 4. Tone Guidelines

#### Do's ✅
- "Silakan unggah file CSV Anda"
- "Prediksi berhasil dilakukan!"
- "Konten Anda berpotensi trending"
- "Mohon lengkapi semua field yang diperlukan"

#### Don'ts ❌
- "Please upload your CSV file"
- "Prediction successful!"
- "Your content will go viral"
- "Please fill all required fields"

### 5. Error Messages (Indonesian)
```python
ERRORS = {
    "file_not_found": "File tidak ditemukan. Silakan periksa kembali.",
    "invalid_format": "Format file tidak valid. Gunakan file CSV.",
    "missing_columns": "Kolom yang diperlukan tidak lengkap.",
    "model_load_error": "Gagal memuat model. Hubungi administrator.",
    "prediction_error": "Terjadi kesalahan saat prediksi. Coba lagi.",
    "empty_data": "Data kosong. Silakan isi semua field.",
}
```

### 6. Success Messages (Indonesian)
```python
SUCCESS = {
    "prediction_done": "✅ Prediksi berhasil dilakukan!",
    "file_uploaded": "✅ File berhasil diunggah!",
    "data_processed": "✅ Data berhasil diproses!",
    "model_loaded": "✅ Model berhasil dimuat!",
}
```

### 7. Chart/Graph Labels
```python
# Plotly chart titles and labels in Indonesian
fig.update_layout(
    title="Performa Konten Berdasarkan Hari",
    xaxis_title="Hari dalam Seminggu",
    yaxis_title="Rata-rata Tayangan",
)
```

### 8. Streamlit Config (Indonesian)
```python
# config.toml or in-app config
st.set_page_config(
    page_title="Prediksi TikTok",
    page_icon="🎯",
    layout="wide",
    initial_sidebar_state="expanded"
)
```

## Implementation Checklist

When developing any UI component, ensure:
- [ ] All text is in Indonesian
- [ ] Tone is consistent (formal but friendly)
- [ ] Terminology matches this skill guide
- [ ] Error messages are clear and helpful
- [ ] Success messages are encouraging
- [ ] Labels are descriptive
- [ ] Help text is provided where needed
- [ ] No English text in user-facing elements

## Notes for Claude Code
- When generating Streamlit code, ALWAYS apply this skill
- Check every string literal for Indonesian translation
- Use this skill as reference for terminology consistency
- If unsure about translation, ask for clarification
```

---

# 📄 requirements.txt
```
streamlit==1.28.0
pandas==2.0.3
numpy==1.24.3
scikit-learn==1.3.0
plotly==5.17.0
joblib==1.3.2
openpyxl==3.1.2
```

---

# 📄 .gitignore
```
# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
venv/
env/
ENV/

# Streamlit
.streamlit/

# IDE
.vscode/
.idea/
*.swp
*.swo

# Data
*.csv
*.xlsx
!dataset_freetiktokscraper_20251111_031559826.csv

# Model (optional - if you want to track model)
# *.pkl

# OS
.DS_Store
Thumbs.db

# Logs
*.log